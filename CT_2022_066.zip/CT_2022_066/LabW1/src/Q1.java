import javax.swing.*;

public class Q1 {
    public static void main(String[] args){
        JFrame myWindow = new JFrame();
        myWindow.setSize(800, 600);
        myWindow.setVisible(true);
        myWindow.setTitle("Welcome");
    }
}
